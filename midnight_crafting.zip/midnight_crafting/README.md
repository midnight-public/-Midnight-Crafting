# Midnight Crafting

Crafting benches with XP levels and an in-game admin panel for qb-core.
Made by Midnight Scripts.

## Requirements
- qb-core
- qb-inventory
- qb-target
- oxmysql

## Install
1. Put the `midnight_crafting` folder in your `resources` folder.
2. Add `ensure midnight_crafting` to `server.cfg` (after qb-core, qb-target, qb-inventory and oxmysql).
3. Start the server. The database tables and a few starter recipes are created automatically.
4. In game, as an admin, type `/admincrafting` to add benches and recipes.

## Admin panel
- Command: `/admincrafting` (change it in `config.lua`).
- Access: qb-core groups listed in `Config.AdminPermissions`, or the ace `midnight_crafting.admin`.
- Recipes: name, category, result item, ingredients, time, XP, required level and success chance.
- Benches: stand where you want the bench, press "Use my position", pick a prop, and optionally restrict it by job or by recipe category.
- Players & XP: add, remove, set or reset the crafting XP of online players.

## Config
Everything is in `config.lua`: language (`en` / `bg`), max craft quantity, XP curve, animation, categories, props and item image path.
If your qb-inventory keeps item images somewhere else, change `Config.ImagePath`.

## How crafting is secured
Nothing is taken when a craft starts. Materials are re-checked, removed and the result given when the craft finishes,
so cancelling or disconnecting never costs items. Distance, job, level, materials and timing are all validated on the server.

## Upgrading from moon_crafting
1. Stop the server and delete the old `moon_crafting` folder.
2. Put `midnight_crafting` in `resources` and change `ensure moon_crafting` to `ensure midnight_crafting` in `server.cfg`.
3. Start the server. The old `moon_crafting_*` tables are renamed automatically, so your benches, recipes and XP stay.
4. If you gave admin access through the ace `moon_crafting.admin`, change it to `midnight_crafting.admin`.
