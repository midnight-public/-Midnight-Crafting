-- Framework / inventory bridge (qb-core + qb-inventory).
-- Everything that touches the framework lives here, so ESX and QBOX
-- support later only means writing another bridge file.

QBCore = exports['qb-core']:GetCoreObject()

MC = {
    Recipes = {},   -- [id] = recipe row
    Benches = {},   -- [id] = bench row
    XpCache = {},   -- [citizenid] = total xp
    Crafting = {},  -- [source] = active craft state
}

Bridge = {}

function Bridge.Identifier(src)
    local p = QBCore.Functions.GetPlayer(src)
    return p and p.PlayerData.citizenid or nil
end

function Bridge.Job(src)
    local p = QBCore.Functions.GetPlayer(src)
    return p and p.PlayerData.job and p.PlayerData.job.name or nil
end

function Bridge.PlayerName(src)
    local p = QBCore.Functions.GetPlayer(src)
    if not p then return 'Unknown' end
    local c = p.PlayerData.charinfo or {}
    return ('%s %s'):format(c.firstname or '?', c.lastname or '')
end

function Bridge.ItemCount(src, name)
    local p = QBCore.Functions.GetPlayer(src)
    if not p then return 0 end
    local total = 0
    for _, it in pairs(p.PlayerData.items or {}) do
        if it and it.name == name then
            total = total + (it.amount or 0)
        end
    end
    return total
end

function Bridge.CanCarry(src, name, amount)
    -- Newer qb-inventory versions export CanAddItem. Older ones do not,
    -- in that case AddItem itself reports a full inventory.
    local ok, res = pcall(function()
        return exports['qb-inventory']:CanAddItem(src, name, amount)
    end)
    if ok and type(res) == 'boolean' then return res end
    return true
end

function Bridge.RemoveItem(src, name, amount)
    local p = QBCore.Functions.GetPlayer(src)
    if not p then return false end
    local ok = p.Functions.RemoveItem(name, amount)
    if ok then
        TriggerClientEvent('qb-inventory:client:ItemBox', src, QBCore.Shared.Items[name], 'remove')
    end
    return ok and true or false
end

function Bridge.AddItem(src, name, amount)
    local p = QBCore.Functions.GetPlayer(src)
    if not p then return false end
    local ok = p.Functions.AddItem(name, amount)
    if ok then
        TriggerClientEvent('qb-inventory:client:ItemBox', src, QBCore.Shared.Items[name], 'add')
    end
    return ok and true or false
end

function Bridge.Notify(src, msg, typ)
    TriggerClientEvent('QBCore:Notify', src, msg, typ or 'primary')
end

function Bridge.IsAdmin(src)
    for _, group in ipairs(Config.AdminPermissions) do
        if QBCore.Functions.HasPermission(src, group) then return true end
    end
    return IsPlayerAceAllowed(src, 'midnight_crafting.admin')
end

function Bridge.OnlinePlayers()
    return QBCore.Functions.GetQBPlayers()
end

function Bridge.ItemExists(name)
    return QBCore.Shared.Items[name] ~= nil
end

function Bridge.ItemData(name)
    local it = QBCore.Shared.Items[name]
    return {
        name = name,
        label = it and it.label or name,
        image = Config.ImagePath .. ((it and it.image) or (name .. '.png')),
    }
end
