-- Admin panel backend. Every callback re-checks permissions on the server.

local Clamp, Contains = MC.Clamp, MC.Contains

local function CategoryExists(id)
    for _, c in ipairs(Config.Categories) do
        if c.id == id then return true end
    end
    return false
end

local function PropExists(model)
    for _, p in ipairs(Config.Props) do
        if p.model == model then return true end
    end
    return false
end

local function Trim(s, max)
    s = tostring(s or ''):gsub('^%s+', ''):gsub('%s+$', '')
    return s:sub(1, max)
end

-------------------------------------------------------------------------------
-- Lists sent to the panel
-------------------------------------------------------------------------------

local function RecipeList()
    local list = {}
    for _, r in pairs(MC.Recipes) do
        list[#list + 1] = {
            id = r.id, label = r.label, category = r.category,
            result_item = r.result_item, result_amount = r.result_amount,
            craft_time = r.craft_time, xp = r.xp, level = r.level, chance = r.chance,
            ingredients = r.ingredients,
        }
    end
    table.sort(list, function(a, b) return a.id < b.id end)
    return list
end

local function BenchList()
    local list = {}
    for _, b in pairs(MC.Benches) do
        list[#list + 1] = {
            id = b.id, label = b.label, model = b.model,
            x = b.x, y = b.y, z = b.z, h = b.h,
            jobs = b.jobs, categories = b.categories, blip = b.blip,
        }
    end
    table.sort(list, function(a, b) return a.id < b.id end)
    return list
end

local function PlayerList()
    local list = {}
    for src, player in pairs(Bridge.OnlinePlayers()) do
        local cid = player.PlayerData.citizenid
        local info = MC.LevelInfo(MC.GetXp(cid))
        list[#list + 1] = {
            id = tonumber(src), name = Bridge.PlayerName(tonumber(src)),
            citizenid = cid, level = info.level, xp = info.total,
        }
    end
    table.sort(list, function(a, b) return a.id < b.id end)
    return list
end

-------------------------------------------------------------------------------
-- Command
-------------------------------------------------------------------------------

RegisterCommand(Config.AdminCommand, function(src)
    if src == 0 then return end
    if not Bridge.IsAdmin(src) then
        return Bridge.Notify(src, 'You do not have permission to use this.', 'error')
    end
    TriggerClientEvent('midnight_crafting:client:openAdmin', src, {
        recipes = RecipeList(),
        benches = BenchList(),
        categories = Config.Categories,
        props = Config.Props,
        maxLevel = Config.Xp.maxLevel,
    })
end, false)

-------------------------------------------------------------------------------
-- Recipes
-------------------------------------------------------------------------------

QBCore.Functions.CreateCallback('midnight_crafting:admin:saveRecipe', function(src, cb, d)
    if not Bridge.IsAdmin(src) or type(d) ~= 'table' then return cb({ ok = false, err = 'No permission.' }) end

    local label = Trim(d.label, 60)
    if label == '' then return cb({ ok = false, err = 'Give the recipe a name.' }) end
    if not CategoryExists(d.category) then return cb({ ok = false, err = 'Pick a category.' }) end
    if not Bridge.ItemExists(d.result_item) then return cb({ ok = false, err = 'The result item does not exist.' }) end

    local merged, order = {}, {}
    for _, ing in ipairs(type(d.ingredients) == 'table' and d.ingredients or {}) do
        if type(ing) == 'table' then
            if not Bridge.ItemExists(ing.item) then
                return cb({ ok = false, err = ('Unknown ingredient: %s'):format(tostring(ing.item)) })
            end
            if merged[ing.item] == nil then order[#order + 1] = ing.item end
            merged[ing.item] = (merged[ing.item] or 0) + Clamp(ing.amount, 1, 1000)
        end
    end
    if #order == 0 then return cb({ ok = false, err = 'Add at least one ingredient.' }) end

    local ingredients = {}
    for _, name in ipairs(order) do
        ingredients[#ingredients + 1] = { item = name, amount = math.min(merged[name], 1000) }
    end

    local row = {
        label, d.category, d.result_item,
        Clamp(d.result_amount, 1, 1000), Clamp(d.craft_time, 1, 600),
        Clamp(d.xp, 0, 100000), Clamp(d.level, 1, Config.Xp.maxLevel),
        Clamp(d.chance, 1, 100), json.encode(ingredients),
    }

    local id = tonumber(d.id)
    if id and MC.Recipes[id] then
        row[#row + 1] = id
        MySQL.update.await(
            'UPDATE midnight_crafting_recipes SET label=?, category=?, result_item=?, result_amount=?, craft_time=?, xp=?, level=?, chance=?, ingredients=? WHERE id=?',
            row
        )
    else
        MySQL.insert.await(
            'INSERT INTO midnight_crafting_recipes (label, category, result_item, result_amount, craft_time, xp, level, chance, ingredients) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
            row
        )
    end

    MC.LoadAll()
    cb({ ok = true, recipes = RecipeList() })
end)

QBCore.Functions.CreateCallback('midnight_crafting:admin:deleteRecipe', function(src, cb, id)
    if not Bridge.IsAdmin(src) then return cb({ ok = false, err = 'No permission.' }) end
    id = tonumber(id)
    if not id or not MC.Recipes[id] then return cb({ ok = false, err = 'Recipe not found.' }) end
    MySQL.update.await('DELETE FROM midnight_crafting_recipes WHERE id = ?', { id })
    MC.LoadAll()
    cb({ ok = true, recipes = RecipeList() })
end)

-------------------------------------------------------------------------------
-- Benches
-------------------------------------------------------------------------------

QBCore.Functions.CreateCallback('midnight_crafting:admin:saveBench', function(src, cb, d)
    if not Bridge.IsAdmin(src) or type(d) ~= 'table' then return cb({ ok = false, err = 'No permission.' }) end

    local label = Trim(d.label, 60)
    if label == '' then return cb({ ok = false, err = 'Give the bench a name.' }) end
    if not PropExists(d.model) then return cb({ ok = false, err = 'Pick a prop.' }) end

    local x, y, z, h = tonumber(d.x), tonumber(d.y), tonumber(d.z), tonumber(d.h) or 0.0
    if not x or not y or not z then return cb({ ok = false, err = 'Set the bench position first.' }) end

    local jobs = {}
    for _, j in ipairs(type(d.jobs) == 'table' and d.jobs or {}) do
        if type(j) == 'string' and QBCore.Shared.Jobs[j] and not Contains(jobs, j) then jobs[#jobs + 1] = j end
    end
    local categories = {}
    for _, c in ipairs(type(d.categories) == 'table' and d.categories or {}) do
        if CategoryExists(c) and not Contains(categories, c) then categories[#categories + 1] = c end
    end

    local row = { label, d.model, x, y, z, h, json.encode(jobs), json.encode(categories), d.blip and 1 or 0 }
    local id = tonumber(d.id)
    if id and MC.Benches[id] then
        row[#row + 1] = id
        MySQL.update.await(
            'UPDATE midnight_crafting_benches SET label=?, model=?, x=?, y=?, z=?, h=?, jobs=?, categories=?, blip=? WHERE id=?',
            row
        )
    else
        MySQL.insert.await(
            'INSERT INTO midnight_crafting_benches (label, model, x, y, z, h, jobs, categories, blip) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
            row
        )
    end

    MC.LoadAll()
    MC.Broadcast()
    cb({ ok = true, benches = BenchList() })
end)

QBCore.Functions.CreateCallback('midnight_crafting:admin:deleteBench', function(src, cb, id)
    if not Bridge.IsAdmin(src) then return cb({ ok = false, err = 'No permission.' }) end
    id = tonumber(id)
    if not id or not MC.Benches[id] then return cb({ ok = false, err = 'Bench not found.' }) end
    MySQL.update.await('DELETE FROM midnight_crafting_benches WHERE id = ?', { id })
    MC.LoadAll()
    MC.Broadcast()
    cb({ ok = true, benches = BenchList() })
end)

-------------------------------------------------------------------------------
-- Players and XP
-------------------------------------------------------------------------------

QBCore.Functions.CreateCallback('midnight_crafting:admin:players', function(src, cb)
    if not Bridge.IsAdmin(src) then return cb({ ok = false, err = 'No permission.' }) end
    cb({ ok = true, players = PlayerList() })
end)

QBCore.Functions.CreateCallback('midnight_crafting:admin:setXp', function(src, cb, d)
    if not Bridge.IsAdmin(src) or type(d) ~= 'table' then return cb({ ok = false, err = 'No permission.' }) end

    local target = tonumber(d.target)
    local cid = target and Bridge.Identifier(target)
    if not cid then return cb({ ok = false, err = 'That player is not online.' }) end

    local amount = Clamp(d.amount, 0, 10000000)
    local current = MC.GetXp(cid)
    if d.mode == 'add' then
        MC.SetXp(cid, current + amount)
    elseif d.mode == 'remove' then
        MC.SetXp(cid, current - amount)
    elseif d.mode == 'set' then
        MC.SetXp(cid, amount)
    elseif d.mode == 'reset' then
        MC.SetXp(cid, 0)
    else
        return cb({ ok = false, err = 'Unknown action.' })
    end

    cb({ ok = true, players = PlayerList() })
end)
