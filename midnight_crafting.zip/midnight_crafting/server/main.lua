-------------------------------------------------------------------------------
-- Helpers
-------------------------------------------------------------------------------

local function Decode(str, fallback)
    if not str or str == '' then return fallback end
    local ok, value = pcall(json.decode, str)
    if ok and value ~= nil then return value end
    return fallback
end

local function Contains(list, value)
    for _, v in ipairs(list or {}) do
        if v == value then return true end
    end
    return false
end

local function Clamp(n, min, max)
    n = tonumber(n) or min
    n = math.floor(n)
    if n < min then return min end
    if n > max then return max end
    return n
end

MC.Clamp = Clamp
MC.Contains = Contains

-------------------------------------------------------------------------------
-- XP
-------------------------------------------------------------------------------

function MC.XpForNext(level)
    return math.floor(Config.Xp.base * (Config.Xp.growth ^ (level - 1)))
end

-- total xp -> { level, xp (inside level), needed (for next level, 0 at max), total }
function MC.LevelInfo(total)
    local level, remaining = 1, total
    while level < Config.Xp.maxLevel do
        local need = MC.XpForNext(level)
        if remaining >= need then
            remaining = remaining - need
            level = level + 1
        else
            break
        end
    end
    local needed = level >= Config.Xp.maxLevel and 0 or MC.XpForNext(level)
    return { level = level, xp = remaining, needed = needed, total = total }
end

function MC.GetXp(citizenid)
    if MC.XpCache[citizenid] == nil then
        MC.XpCache[citizenid] = MySQL.scalar.await('SELECT xp FROM midnight_crafting_xp WHERE identifier = ?', { citizenid }) or 0
    end
    return MC.XpCache[citizenid]
end

function MC.SetXp(citizenid, total)
    total = math.max(0, math.floor(total))
    MC.XpCache[citizenid] = total
    MySQL.insert(
        'INSERT INTO midnight_crafting_xp (identifier, xp) VALUES (?, ?) ON DUPLICATE KEY UPDATE xp = VALUES(xp)',
        { citizenid, total }
    )
end

-------------------------------------------------------------------------------
-- Database
-------------------------------------------------------------------------------

-- Older installs used the moon_crafting_* table names. Rename them once so no data is lost.
local function MigrateOldTables()
    for _, name in ipairs({ 'xp', 'recipes', 'benches' }) do
        local old, new = 'moon_crafting_' .. name, 'midnight_crafting_' .. name
        local sql = 'SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = ?'
        local hasOld = MySQL.scalar.await(sql, { old }) or 0
        local hasNew = MySQL.scalar.await(sql, { new }) or 0
        if hasOld > 0 and hasNew == 0 then
            MySQL.query.await(('RENAME TABLE `%s` TO `%s`'):format(old, new))
            print(('[midnight_crafting] migrated table %s -> %s'):format(old, new))
        end
    end
end

local function CreateTables()
    MigrateOldTables()
    MySQL.query.await([[
        CREATE TABLE IF NOT EXISTS midnight_crafting_xp (
            identifier VARCHAR(60) NOT NULL PRIMARY KEY,
            xp INT NOT NULL DEFAULT 0
        )
    ]])
    MySQL.query.await([[
        CREATE TABLE IF NOT EXISTS midnight_crafting_recipes (
            id INT AUTO_INCREMENT PRIMARY KEY,
            label VARCHAR(60) NOT NULL,
            category VARCHAR(40) NOT NULL,
            result_item VARCHAR(60) NOT NULL,
            result_amount INT NOT NULL DEFAULT 1,
            craft_time INT NOT NULL DEFAULT 5,
            xp INT NOT NULL DEFAULT 0,
            level INT NOT NULL DEFAULT 1,
            chance INT NOT NULL DEFAULT 100,
            ingredients LONGTEXT NOT NULL
        )
    ]])
    MySQL.query.await([[
        CREATE TABLE IF NOT EXISTS midnight_crafting_benches (
            id INT AUTO_INCREMENT PRIMARY KEY,
            label VARCHAR(60) NOT NULL,
            model VARCHAR(60) NOT NULL,
            x DOUBLE NOT NULL,
            y DOUBLE NOT NULL,
            z DOUBLE NOT NULL,
            h DOUBLE NOT NULL DEFAULT 0,
            jobs LONGTEXT NOT NULL,
            categories LONGTEXT NOT NULL,
            blip TINYINT NOT NULL DEFAULT 0
        )
    ]])
end

local function SeedRecipes()
    local count = MySQL.scalar.await('SELECT COUNT(*) FROM midnight_crafting_recipes') or 0
    if count > 0 then return end

    for _, r in ipairs(Config.DefaultRecipes) do
        local valid = Bridge.ItemExists(r.item)
        local ingredients = {}
        for _, ing in ipairs(r.ingredients) do
            if not Bridge.ItemExists(ing[1]) then valid = false end
            ingredients[#ingredients + 1] = { item = ing[1], amount = ing[2] }
        end
        if valid then
            MySQL.insert.await(
                'INSERT INTO midnight_crafting_recipes (label, category, result_item, result_amount, craft_time, xp, level, chance, ingredients) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
                { r.label, r.category, r.item, r.amount, r.time, r.xp, r.level, r.chance, json.encode(ingredients) }
            )
        end
    end
end

function MC.LoadAll()
    MC.Recipes = {}
    for _, r in ipairs(MySQL.query.await('SELECT * FROM midnight_crafting_recipes') or {}) do
        r.ingredients = Decode(r.ingredients, {})
        MC.Recipes[r.id] = r
    end

    MC.Benches = {}
    for _, b in ipairs(MySQL.query.await('SELECT * FROM midnight_crafting_benches') or {}) do
        b.jobs = Decode(b.jobs, {})
        b.categories = Decode(b.categories, {})
        b.blip = (b.blip == 1 or b.blip == true)
        MC.Benches[b.id] = b
    end
end

-- Benches as the clients need them (no job lists, no categories)
function MC.PublicBenches()
    local list = {}
    for _, b in pairs(MC.Benches) do
        list[#list + 1] = { id = b.id, label = b.label, model = b.model, x = b.x, y = b.y, z = b.z, h = b.h, blip = b.blip }
    end
    table.sort(list, function(a, b) return a.id < b.id end)
    return list
end

function MC.Broadcast()
    TriggerClientEvent('midnight_crafting:client:sync', -1, MC.PublicBenches())
end

CreateThread(function()
    CreateTables()
    SeedRecipes()
    MC.LoadAll()
    MC.Broadcast()
end)

RegisterNetEvent('midnight_crafting:server:requestSync', function()
    TriggerClientEvent('midnight_crafting:client:sync', source, MC.PublicBenches())
end)

-------------------------------------------------------------------------------
-- Bench access and payloads
-------------------------------------------------------------------------------

local function NearBench(src, bench)
    local coords = GetEntityCoords(GetPlayerPed(src))
    return #(coords - vector3(bench.x, bench.y, bench.z)) <= (Config.InteractDistance + 3.0)
end

local function HasBenchAccess(src, bench)
    if #bench.jobs == 0 then return true end
    return Contains(bench.jobs, Bridge.Job(src))
end

local function RecipeAtBench(recipe, bench)
    if #bench.categories == 0 then return true end
    return Contains(bench.categories, recipe.category)
end

local function BuildPayload(src, bench)
    local cid = Bridge.Identifier(src)
    local recipes, seen = {}, {}

    for _, r in pairs(MC.Recipes) do
        if RecipeAtBench(r, bench) then
            local ingredients = {}
            for _, ing in ipairs(r.ingredients) do
                local data = Bridge.ItemData(ing.item)
                data.amount = ing.amount
                data.have = Bridge.ItemCount(src, ing.item)
                ingredients[#ingredients + 1] = data
            end
            local result = Bridge.ItemData(r.result_item)
            result.amount = r.result_amount
            recipes[#recipes + 1] = {
                id = r.id, label = r.label, category = r.category,
                time = r.craft_time, xp = r.xp, level = r.level, chance = r.chance,
                result = result, ingredients = ingredients,
            }
            seen[r.category] = true
        end
    end

    table.sort(recipes, function(a, b)
        if a.level ~= b.level then return a.level < b.level end
        return a.label < b.label
    end)

    local categories = {}
    for _, c in ipairs(Config.Categories) do
        if seen[c.id] then categories[#categories + 1] = c end
    end

    return {
        bench = { id = bench.id, label = bench.label },
        player = MC.LevelInfo(MC.GetXp(cid)),
        recipes = recipes,
        categories = categories,
        maxQty = Config.MaxQuantity,
    }
end

RegisterNetEvent('midnight_crafting:server:open', function(benchId)
    local src = source
    local bench = MC.Benches[tonumber(benchId)]
    if not bench or not Bridge.Identifier(src) then return end
    if not NearBench(src, bench) then return Bridge.Notify(src, L('n_too_far'), 'error') end
    if not HasBenchAccess(src, bench) then return Bridge.Notify(src, L('n_no_access'), 'error') end
    TriggerClientEvent('midnight_crafting:client:open', src, BuildPayload(src, bench))
end)

-------------------------------------------------------------------------------
-- Crafting
-- Nothing is taken from the player when a craft starts. Materials are checked
-- again, removed and the result is given only when the craft finishes, so
-- cancelling, disconnecting or crashing can never cost anyone items.
-------------------------------------------------------------------------------

local function HasMaterials(src, recipe, qty)
    for _, ing in ipairs(recipe.ingredients) do
        if Bridge.ItemCount(src, ing.item) < ing.amount * qty then return false end
    end
    return true
end

QBCore.Functions.CreateCallback('midnight_crafting:start', function(src, cb, benchId, recipeId, qty)
    local bench = MC.Benches[tonumber(benchId)]
    local recipe = MC.Recipes[tonumber(recipeId)]
    local cid = Bridge.Identifier(src)
    qty = Clamp(qty, 1, Config.MaxQuantity)

    if not cid or not bench or not recipe then return cb({ ok = false, msg = L('n_error') }) end
    if MC.Crafting[src] then return cb({ ok = false, msg = L('n_busy') }) end
    if not NearBench(src, bench) then return cb({ ok = false, msg = L('n_too_far') }) end
    if not HasBenchAccess(src, bench) then return cb({ ok = false, msg = L('n_no_access') }) end
    if not RecipeAtBench(recipe, bench) then return cb({ ok = false, msg = L('n_no_recipe') }) end

    local info = MC.LevelInfo(MC.GetXp(cid))
    if info.level < recipe.level then return cb({ ok = false, msg = L('n_level', recipe.level) }) end
    if not HasMaterials(src, recipe, qty) then return cb({ ok = false, msg = L('n_missing') }) end
    if not Bridge.CanCarry(src, recipe.result_item, recipe.result_amount * qty) then
        return cb({ ok = false, msg = L('n_full') })
    end

    local duration = recipe.craft_time * qty * 1000
    MC.Crafting[src] = { bench = bench.id, recipe = recipe.id, qty = qty, startedAt = GetGameTimer(), duration = duration }
    cb({ ok = true, duration = duration })
end)

QBCore.Functions.CreateCallback('midnight_crafting:finish', function(src, cb)
    local state = MC.Crafting[src]
    MC.Crafting[src] = nil
    if not state then return cb({ ok = false, message = L('n_error') }) end

    local bench = MC.Benches[state.bench]
    local recipe = MC.Recipes[state.recipe]
    local cid = Bridge.Identifier(src)
    if not bench or not recipe or not cid then return cb({ ok = false, message = L('n_error') }) end

    -- the client must have waited (almost) the whole duration
    if GetGameTimer() - state.startedAt < state.duration - 750 then
        return cb({ ok = false, message = L('n_error') })
    end
    if not NearBench(src, bench) then return cb({ ok = false, message = L('n_too_far') }) end
    if not HasMaterials(src, recipe, state.qty) then return cb({ ok = false, message = L('n_missing') }) end
    if not Bridge.CanCarry(src, recipe.result_item, recipe.result_amount * state.qty) then
        return cb({ ok = false, message = L('n_full') })
    end

    -- take materials
    local taken = {}
    for _, ing in ipairs(recipe.ingredients) do
        if Bridge.RemoveItem(src, ing.item, ing.amount * state.qty) then
            taken[#taken + 1] = ing
        else
            for _, t in ipairs(taken) do Bridge.AddItem(src, t.item, t.amount * state.qty) end
            return cb({ ok = false, message = L('n_missing') })
        end
    end

    -- roll every unit separately
    local successes = 0
    for _ = 1, state.qty do
        if math.random(100) <= recipe.chance then successes = successes + 1 end
    end

    if successes > 0 then
        if not Bridge.AddItem(src, recipe.result_item, recipe.result_amount * successes) then
            for _, t in ipairs(taken) do Bridge.AddItem(src, t.item, t.amount * state.qty) end
            return cb({ ok = false, message = L('n_full') })
        end
    end

    -- xp
    local before = MC.LevelInfo(MC.GetXp(cid))
    local gained = recipe.xp * successes
    if gained > 0 then MC.SetXp(cid, MC.GetXp(cid) + gained) end
    local after = MC.LevelInfo(MC.GetXp(cid))

    local label = Bridge.ItemData(recipe.result_item).label
    local failed = state.qty - successes
    local message, kind
    if successes == 0 then
        message, kind = L('n_failed'), 'bad'
    elseif failed > 0 then
        message, kind = L('n_partial', recipe.result_amount * successes, label, failed), 'good'
    else
        message, kind = L('n_success', recipe.result_amount * successes, label), 'good'
    end

    cb({
        ok = true,
        message = message,
        kind = kind,
        xpGained = gained,
        levelUp = after.level > before.level and L('n_levelup', after.level) or nil,
        payload = BuildPayload(src, bench),
    })
end)

RegisterNetEvent('midnight_crafting:server:cancel', function()
    MC.Crafting[source] = nil
end)

AddEventHandler('playerDropped', function()
    MC.Crafting[source] = nil
end)
