'use strict';

const RES = typeof GetParentResourceName === 'function' ? GetParentResourceName() : 'midnight_crafting';
const post = (name, data = {}) =>
  fetch(`https://${RES}/${name}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json; charset=UTF-8' },
    body: JSON.stringify(data),
  }).then(r => r.json()).catch(() => ({}));

const $ = (s, r = document) => r.querySelector(s);
const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const imgFallback = "this.style.visibility='hidden'";

let LOC = {};
const T = (k, ...a) => String(LOC[k] ?? k).replace(/\{(\d+)\}/g, (_, i) => a[i] ?? '');

function toast(msg, kind = '') {
  const el = document.createElement('div');
  el.className = `toast ${kind}`;
  el.textContent = msg;
  $('#toasts').appendChild(el);
  setTimeout(() => el.remove(), 3600);
}

function showScreen(id) {
  $('#craft').classList.toggle('hidden', id !== 'craft');
  $('#admin').classList.toggle('hidden', id !== 'admin');
}
function hideAll() {
  showScreen(null);
  closeModal();
}

/* =====================================================================
   Player crafting menu
   ===================================================================== */

const C = { data: null, cat: 'all', q: '', sel: null, qty: 1, busy: false, duration: 0 };

function openCrafting(data) {
  Object.assign(C, { data, cat: 'all', q: '', sel: null, qty: 1, busy: false, duration: 0 });
  buildCraftShell();
  renderCraft();
  showScreen('craft');
}

function buildCraftShell() {
  $('#craft').innerHTML = `
    <div class="shell">
      <header class="top">
        <div class="orb" id="orb"><span id="lvl">1</span></div>
        <div class="who">
          <h1 id="benchName"></h1>
          <div class="xpline"><div class="xpbar"><i id="xpFill"></i></div><span id="xpText"></span></div>
        </div>
        <label class="search"><i class="fa-solid fa-magnifying-glass"></i><input id="q" type="text" autocomplete="off"></label>
        <button class="icon-btn" id="closeBtn" aria-label="Close"><i class="fa-solid fa-xmark"></i></button>
      </header>
      <div class="body">
        <nav class="cats" id="cats"></nav>
        <section class="recipes" id="recipes"></section>
        <aside class="detail" id="detail"></aside>
      </div>
    </div>`;

  $('#q').placeholder = T('ui_search');
  $('#q').addEventListener('input', e => { C.q = e.target.value.trim().toLowerCase(); renderRecipes(); });
  $('#closeBtn').addEventListener('click', closeCraft);
  $('#cats').addEventListener('click', e => {
    const b = e.target.closest('.cat'); if (!b) return;
    C.cat = b.dataset.id; renderCats(); renderRecipes();
  });
  $('#recipes').addEventListener('click', e => {
    const b = e.target.closest('.card'); if (!b || C.busy) return;
    C.sel = Number(b.dataset.id); C.qty = 1; renderRecipes(); renderDetail();
  });
}

function closeCraft() { post('close'); }

function renderCraft() { renderHeader(); renderCats(); renderRecipes(); renderDetail(); }

function renderHeader() {
  const p = C.data.player;
  const pct = p.needed > 0 ? Math.min(100, (p.xp / p.needed) * 100) : 100;
  $('#benchName').textContent = C.data.bench.label;
  $('#lvl').textContent = p.level;
  $('#orb').style.setProperty('--p', pct.toFixed(1));
  $('#xpFill').style.width = pct + '%';
  $('#xpText').textContent = p.needed > 0 ? `${p.xp} / ${p.needed} XP` : T('ui_max');
}

function renderCats() {
  const list = [{ id: 'all', label: T('ui_all'), icon: 'fa-layer-group' }, ...C.data.categories];
  $('#cats').innerHTML = list.map(c => {
    const n = c.id === 'all' ? C.data.recipes.length : C.data.recipes.filter(r => r.category === c.id).length;
    return `<button class="cat ${C.cat === c.id ? 'on' : ''}" data-id="${esc(c.id)}"><i class="fa-solid ${esc(c.icon)}"></i>${esc(c.label)}<b>${n}</b></button>`;
  }).join('');
}

const isLocked = r => r.level > C.data.player.level;
const maxQty = r => Math.max(1, r.ingredients.reduce((m, i) => Math.min(m, Math.floor(i.have / i.amount)), C.data.maxQty));
const selected = () => C.data.recipes.find(r => r.id === C.sel);

function renderRecipes() {
  const list = C.data.recipes.filter(r =>
    (C.cat === 'all' || r.category === C.cat) &&
    (!C.q || r.label.toLowerCase().includes(C.q) || r.result.label.toLowerCase().includes(C.q)));

  if (!list.length) {
    $('#recipes').innerHTML = `<div class="empty">${esc(C.data.recipes.length ? T('ui_no_match') : T('ui_empty'))}</div>`;
    return;
  }
  $('#recipes').innerHTML = list.map(r => `
    <button class="card ${isLocked(r) ? 'locked' : ''} ${r.id === C.sel ? 'on' : ''}" data-id="${r.id}">
      <img src="${esc(r.result.image)}" onerror="${imgFallback}" alt="">
      <span class="cname">${esc(r.label)}</span>
      <span class="cmeta">${isLocked(r) ? `<i class="fa-solid fa-lock"></i> ${esc(T('ui_lv', r.level))}` : r.time + 's'}</span>
    </button>`).join('');
}

function renderDetail() {
  const box = $('#detail');
  const r = selected();
  if (!r) {
    box.innerHTML = `<div class="placeholder"><i class="fa-regular fa-moon" style="font-size:30px;margin-bottom:14px;display:block;color:var(--accent)"></i>${esc(T('ui_pick'))}</div>`;
    return;
  }
  const locked = isLocked(r);
  C.qty = Math.min(Math.max(1, C.qty), C.data.maxQty);
  const short = r.ingredients.some(i => i.have < i.amount * C.qty);

  const action = C.busy
    ? `<div class="crafting-label">${esc(T('ui_crafting'))}</div>
       <div class="prog"><i id="progFill"></i></div>
       <button class="btn ghost" id="cancelBtn">${esc(T('ui_cancel'))}</button>`
    : `${locked ? `<div class="notice"><i class="fa-solid fa-lock"></i> ${esc(T('ui_locked', r.level))}</div>` : short ? `<div class="notice">${esc(T('ui_missing'))}</div>` : ''}
       <button class="btn" id="craftBtn" ${locked || short ? 'disabled' : ''}>${esc(T('ui_craft'))}</button>`;

  box.innerHTML = `
    <div class="hero">
      <img src="${esc(r.result.image)}" onerror="${imgFallback}" alt="">
      <div><h2>${esc(r.label)}</h2><p>${esc(T('ui_you_get', r.result.amount * C.qty, r.result.label))}</p></div>
    </div>
    <div class="stats">
      <div class="stat"><b>${r.time * C.qty}s</b><span>${esc(T('ui_time'))}</span></div>
      <div class="stat"><b>${r.chance}%</b><span>${esc(T('ui_chance'))}</span></div>
      <div class="stat"><b>+${r.xp * C.qty}</b><span>${esc(T('ui_reward'))}</span></div>
    </div>
    <h3>${esc(T('ui_ingredients'))}</h3>
    <div class="ings">
      ${r.ingredients.map(i => `
        <div class="ing ${i.have < i.amount * C.qty ? 'short' : ''}">
          <img src="${esc(i.image)}" onerror="${imgFallback}" alt="">
          <span>${esc(i.label)}</span>
          <em>${i.have} / ${i.amount * C.qty}</em>
        </div>`).join('')}
    </div>
    <div class="spacer"></div>
    <div class="qty">
      <label>${esc(T('ui_quantity'))}</label>
      <div class="stepper">
        <button data-q="-1" ${C.busy ? 'disabled' : ''}><i class="fa-solid fa-minus"></i></button>
        <b>${C.qty}</b>
        <button data-q="1" ${C.busy ? 'disabled' : ''}><i class="fa-solid fa-plus"></i></button>
        <button class="max" data-q="max" ${C.busy ? 'disabled' : ''}>${esc(T('ui_max_qty'))}</button>
      </div>
    </div>
    ${action}`;

  box.querySelectorAll('[data-q]').forEach(b => b.addEventListener('click', () => {
    const v = b.dataset.q;
    C.qty = v === 'max' ? maxQty(r) : C.qty + Number(v);
    C.qty = Math.min(Math.max(1, C.qty), C.data.maxQty);
    renderDetail();
  }));

  const craftBtn = $('#craftBtn');
  if (craftBtn) craftBtn.addEventListener('click', startCraft);
  const cancelBtn = $('#cancelBtn');
  if (cancelBtn) cancelBtn.addEventListener('click', () => post('cancel'));

  if (C.busy) {
    const fill = $('#progFill');
    void fill.offsetWidth;
    fill.style.transitionDuration = C.duration + 'ms';
    fill.style.width = '100%';
  }
}

async function startCraft() {
  const r = selected();
  if (!r || C.busy) return;
  const res = await post('craft', { recipeId: r.id, qty: C.qty });
  if (res && res.ok) {
    C.busy = true;
    C.duration = res.duration;
    renderDetail();
  } else if (res && res.msg) {
    toast(res.msg, 'bad');
  }
}

function craftFinished(res) {
  C.busy = false;
  if (res && res.ok) {
    C.data = res.payload;
    toast(res.message, res.kind || 'good');
    if (res.levelUp) setTimeout(() => toast(res.levelUp, 'level'), 500);
  } else if (res && res.message) {
    toast(res.message, 'bad');
  }
  if (!$('#craft').classList.contains('hidden')) renderCraft();
}

/* =====================================================================
   Admin panel
   ===================================================================== */

const A = { tab: 'recipes', data: null, items: {}, players: [], filter: '' };
const itemOf = name => A.items[name] || { name, label: name, image: '' };
const catLabel = id => (A.data.categories.find(c => c.id === id) || {}).label || id;
const propLabel = m => (A.data.props.find(p => p.model === m) || {}).label || m;

function openAdmin(data) {
  A.data = data;
  A.tab = 'recipes';
  A.filter = '';
  A.items = {};
  data.items.forEach(i => { A.items[i.name] = i; });
  $('#itemlist').innerHTML = data.items.map(i => `<option value="${esc(i.name)}">${esc(i.label)}</option>`).join('');
  $('#joblist').innerHTML = data.jobs.map(j => `<option value="${esc(j.name)}">${esc(j.label)}</option>`).join('');
  renderAdmin();
  showScreen('admin');
}

const TABS = [
  { id: 'recipes', label: 'Recipes', icon: 'fa-scroll' },
  { id: 'benches', label: 'Benches', icon: 'fa-screwdriver-wrench' },
  { id: 'players', label: 'Players & XP', icon: 'fa-user-group' },
];

function renderAdmin() {
  $('#admin').innerHTML = `
    <div class="admin-shell">
      <aside class="side">
        <div class="brand"><i class="fa-solid fa-moon"></i>Midnight Crafting</div>
        ${TABS.map(t => `<button class="cat ${A.tab === t.id ? 'on' : ''}" data-tab="${t.id}"><i class="fa-solid ${t.icon}"></i>${t.label}</button>`).join('')}
        <div class="grow"></div>
        <button class="cat" id="adminClose"><i class="fa-solid fa-xmark"></i>Close</button>
      </aside>
      <section class="main" id="adminMain"></section>
    </div>`;
  $('#admin').querySelectorAll('[data-tab]').forEach(b => b.addEventListener('click', () => {
    A.tab = b.dataset.tab;
    renderAdmin();
  }));
  $('#adminClose').addEventListener('click', () => post('adminClose'));
  renderTab();
}

function renderTab() {
  if (A.tab === 'recipes') return renderRecipesTab();
  if (A.tab === 'benches') return renderBenchesTab();
  return renderPlayersTab();
}

/* ---------- recipes ---------- */

function renderRecipesTab() {
  const q = A.filter.toLowerCase();
  const list = A.data.recipes.filter(r => !q || r.label.toLowerCase().includes(q) || r.result_item.includes(q));
  $('#adminMain').innerHTML = `
    <div class="bar">
      <h1>Recipes</h1>
      <label class="search"><i class="fa-solid fa-magnifying-glass"></i><input id="rq" placeholder="Search" value="${esc(A.filter)}" autocomplete="off"></label>
      <button class="btn sm" id="newRecipe"><i class="fa-solid fa-plus"></i> New recipe</button>
    </div>
    <div class="content">
      <table class="table">
        <thead><tr><th>Recipe</th><th>Category</th><th>Level</th><th>Time</th><th>XP</th><th>Chance</th><th>Ingredients</th><th></th></tr></thead>
        <tbody>
          ${list.map(r => {
            const it = itemOf(r.result_item);
            return `<tr>
              <td><div class="cellitem"><img src="${esc(it.image)}" onerror="${imgFallback}" alt=""><div>${esc(r.label)}<div class="muted">${r.result_amount}x ${esc(it.label)}</div></div></div></td>
              <td>${esc(catLabel(r.category))}</td><td>${r.level}</td><td>${r.craft_time}s</td><td>${r.xp}</td><td>${r.chance}%</td>
              <td class="muted">${r.ingredients.map(i => `${i.amount}x ${esc(itemOf(i.item).label)}`).join(', ')}</td>
              <td><div class="row-actions">
                <button class="icon-btn" data-edit="${r.id}" title="Edit"><i class="fa-solid fa-pen"></i></button>
                <button class="icon-btn" data-del="${r.id}" title="Delete"><i class="fa-solid fa-trash"></i></button>
              </div></td></tr>`;
          }).join('') || `<tr><td colspan="8" class="muted" style="padding:40px;text-align:center">No recipes yet.</td></tr>`}
        </tbody>
      </table>
    </div>`;
  $('#rq').addEventListener('input', e => { A.filter = e.target.value; renderRecipesTab(); const i = $('#rq'); i.focus(); i.setSelectionRange(i.value.length, i.value.length); });
  $('#newRecipe').addEventListener('click', () => recipeForm(null));
  $('#adminMain').querySelectorAll('[data-edit]').forEach(b => b.addEventListener('click', () => recipeForm(A.data.recipes.find(r => r.id === Number(b.dataset.edit)))));
  $('#adminMain').querySelectorAll('[data-del]').forEach(b => b.addEventListener('click', () => confirmBox('Delete this recipe?', async () => {
    const res = await post('adminDeleteRecipe', Number(b.dataset.del));
    if (res.ok) { A.data.recipes = res.recipes; renderTab(); toast('Recipe deleted', 'good'); } else toast(res.err || 'Failed', 'bad');
  })));
}

function itemField(id, value) {
  return `<div class="itemfield"><input id="${id}" list="itemlist" value="${esc(value)}" placeholder="item name" autocomplete="off"><img id="${id}_img" alt=""></div>`;
}
function bindItemPreview(id) {
  const input = $('#' + id), img = $('#' + id + '_img');
  const sync = () => { const it = A.items[input.value.trim()]; img.src = it ? it.image : ''; img.style.display = it ? 'block' : 'none'; };
  input.addEventListener('input', sync); sync();
}

function recipeForm(rec) {
  const r = rec || { label: '', category: A.data.categories[0].id, result_item: '', result_amount: 1, craft_time: 5, xp: 10, level: 1, chance: 100, ingredients: [{ item: '', amount: 1 }] };
  openModal(`
    <div class="mbox">
      <h2>${rec ? 'Edit recipe' : 'New recipe'}</h2>
      <div class="fgrid">
        <label class="field">Name<input id="f_label" value="${esc(r.label)}" maxlength="60"></label>
        <label class="field">Category<select id="f_cat">${A.data.categories.map(c => `<option value="${esc(c.id)}" ${c.id === r.category ? 'selected' : ''}>${esc(c.label)}</option>`).join('')}</select></label>
        <label class="field">Result item${itemField('f_item', r.result_item)}</label>
        <label class="field">Result amount<input id="f_amt" type="number" min="1" value="${r.result_amount}"></label>
        <label class="field">Craft time per item (seconds)<input id="f_time" type="number" min="1" value="${r.craft_time}"></label>
        <label class="field">XP per success<input id="f_xp" type="number" min="0" value="${r.xp}"></label>
        <label class="field">Required level (1 - ${A.data.maxLevel})<input id="f_lvl" type="number" min="1" max="${A.data.maxLevel}" value="${r.level}"></label>
        <label class="field">Success chance (%)<input id="f_chance" type="number" min="1" max="100" value="${r.chance}"></label>
      </div>
      <div class="subhead"><span>Ingredients</span><button class="btn ghost sm" id="addIng"><i class="fa-solid fa-plus"></i> Add</button></div>
      <div id="ingRows"></div>
      <div class="mactions"><button class="btn ghost sm" id="mCancel">Cancel</button><button class="btn sm" id="mSave">Save</button></div>
    </div>`);

  bindItemPreview('f_item');
  const rows = $('#ingRows');
  const addRow = (item = '', amount = 1) => {
    const row = document.createElement('div');
    row.className = 'ingrow';
    row.innerHTML = `<input class="i_item" list="itemlist" value="${esc(item)}" placeholder="item name" autocomplete="off"><input class="i_amt" type="number" min="1" value="${amount}"><button class="icon-btn" title="Remove"><i class="fa-solid fa-xmark"></i></button>`;
    row.querySelector('button').addEventListener('click', () => row.remove());
    rows.appendChild(row);
  };
  r.ingredients.forEach(i => addRow(i.item, i.amount));
  $('#addIng').addEventListener('click', () => addRow());
  $('#mCancel').addEventListener('click', closeModal);
  $('#mSave').addEventListener('click', async () => {
    const body = {
      id: rec ? rec.id : null,
      label: $('#f_label').value, category: $('#f_cat').value,
      result_item: $('#f_item').value.trim(), result_amount: Number($('#f_amt').value),
      craft_time: Number($('#f_time').value), xp: Number($('#f_xp').value),
      level: Number($('#f_lvl').value), chance: Number($('#f_chance').value),
      ingredients: [...rows.querySelectorAll('.ingrow')].map(row => ({ item: row.querySelector('.i_item').value.trim(), amount: Number(row.querySelector('.i_amt').value) })).filter(i => i.item),
    };
    const res = await post('adminSaveRecipe', body);
    if (res.ok) { A.data.recipes = res.recipes; closeModal(); renderTab(); toast('Recipe saved', 'good'); } else toast(res.err || 'Failed', 'bad');
  });
}

/* ---------- benches ---------- */

function renderBenchesTab() {
  $('#adminMain').innerHTML = `
    <div class="bar"><h1>Benches</h1><button class="btn sm" id="newBench"><i class="fa-solid fa-plus"></i> New bench</button></div>
    <div class="content">
      ${A.data.benches.map(b => `
        <div class="bench-card">
          <div class="info">
            <h4>${esc(b.label)}</h4>
            <p>${esc(propLabel(b.model))} at ${b.x.toFixed(1)}, ${b.y.toFixed(1)}, ${b.z.toFixed(1)}${b.blip ? ' with map blip' : ''}</p>
            <div class="chips">
              ${b.jobs.length ? b.jobs.map(j => `<span class="chip"><i class="fa-solid fa-briefcase"></i>${esc(j)}</span>`).join('') : '<span class="chip pick">All jobs</span>'}
              ${b.categories.length ? b.categories.map(c => `<span class="chip"><i class="fa-solid fa-tag"></i>${esc(catLabel(c))}</span>`).join('') : '<span class="chip pick">All categories</span>'}
            </div>
          </div>
          <div class="row-actions">
            <button class="icon-btn" data-go="${b.id}" title="Teleport"><i class="fa-solid fa-location-arrow"></i></button>
            <button class="icon-btn" data-edit="${b.id}" title="Edit"><i class="fa-solid fa-pen"></i></button>
            <button class="icon-btn" data-del="${b.id}" title="Delete"><i class="fa-solid fa-trash"></i></button>
          </div>
        </div>`).join('') || '<div class="muted" style="padding:50px;text-align:center">No benches yet. Stand where you want one and press New bench.</div>'}
    </div>`;
  const find = b => A.data.benches.find(x => x.id === Number(b.dataset.edit || b.dataset.go || b.dataset.del));
  $('#newBench').addEventListener('click', () => benchForm(null));
  $('#adminMain').querySelectorAll('[data-edit]').forEach(b => b.addEventListener('click', () => benchForm(find(b))));
  $('#adminMain').querySelectorAll('[data-go]').forEach(b => b.addEventListener('click', () => { const x = find(b); post('adminGoto', { x: x.x, y: x.y, z: x.z }); }));
  $('#adminMain').querySelectorAll('[data-del]').forEach(b => b.addEventListener('click', () => confirmBox('Delete this bench?', async () => {
    const res = await post('adminDeleteBench', Number(b.dataset.del));
    if (res.ok) { A.data.benches = res.benches; renderTab(); toast('Bench deleted', 'good'); } else toast(res.err || 'Failed', 'bad');
  })));
}

function benchForm(bench) {
  const b = bench || { label: '', model: A.data.props[0].model, x: '', y: '', z: '', h: 0, jobs: [], categories: [], blip: false };
  const jobs = [...b.jobs];
  const cats = new Set(b.categories);
  openModal(`
    <div class="mbox">
      <h2>${bench ? 'Edit bench' : 'New bench'}</h2>
      <div class="fgrid">
        <label class="field">Name<input id="b_label" value="${esc(b.label)}" maxlength="60" placeholder="Workshop bench"></label>
        <label class="field">Prop<select id="b_model">${A.data.props.map(p => `<option value="${esc(p.model)}" ${p.model === b.model ? 'selected' : ''}>${esc(p.label)}</option>`).join('')}</select></label>
        <label class="field">X<input id="b_x" type="number" step="0.01" value="${b.x}"></label>
        <label class="field">Y<input id="b_y" type="number" step="0.01" value="${b.y}"></label>
        <label class="field">Z<input id="b_z" type="number" step="0.01" value="${b.z}"></label>
        <label class="field">Heading<input id="b_h" type="number" step="0.01" value="${b.h}"></label>
        <div class="field full"><button class="btn ghost sm" id="useMe" style="align-self:flex-start"><i class="fa-solid fa-crosshairs"></i> Use my position (1 m in front of me)</button></div>
        <div class="field full">Allowed categories (none selected = all)<div class="chips" id="b_cats">
          ${A.data.categories.map(c => `<span class="chip pick ${cats.has(c.id) ? 'on' : ''}" data-id="${esc(c.id)}">${esc(c.label)}</span>`).join('')}
        </div></div>
        <div class="field full">Allowed jobs (none = everyone)
          <div class="ingrow" style="grid-template-columns:1fr 90px;margin:0"><input id="b_jobin" list="joblist" placeholder="job name" autocomplete="off"><button class="btn ghost sm" id="b_jobadd">Add</button></div>
          <div class="chips" id="b_jobs"></div>
        </div>
        <label class="field full" style="flex-direction:row;align-items:center;gap:10px"><input type="checkbox" id="b_blip" ${b.blip ? 'checked' : ''} style="width:18px;height:18px">Show a blip on the map</label>
      </div>
      <div class="mactions"><button class="btn ghost sm" id="mCancel">Cancel</button><button class="btn sm" id="mSave">Save</button></div>
    </div>`);

  const jobBox = $('#b_jobs');
  const drawJobs = () => {
    jobBox.innerHTML = jobs.map((j, i) => `<span class="chip" data-i="${i}" style="cursor:pointer">${esc(j)} <i class="fa-solid fa-xmark"></i></span>`).join('');
    jobBox.querySelectorAll('.chip').forEach(c => c.addEventListener('click', () => { jobs.splice(Number(c.dataset.i), 1); drawJobs(); }));
  };
  drawJobs();
  $('#b_jobadd').addEventListener('click', () => {
    const v = $('#b_jobin').value.trim();
    if (v && !jobs.includes(v)) jobs.push(v);
    $('#b_jobin').value = '';
    drawJobs();
  });
  $('#b_cats').querySelectorAll('.chip').forEach(c => c.addEventListener('click', () => {
    cats.has(c.dataset.id) ? cats.delete(c.dataset.id) : cats.add(c.dataset.id);
    c.classList.toggle('on');
  }));
  $('#useMe').addEventListener('click', async () => {
    const p = await post('adminGetCoords');
    if (p && p.x !== undefined) { $('#b_x').value = p.x; $('#b_y').value = p.y; $('#b_z').value = p.z; $('#b_h').value = p.h; }
  });
  $('#mCancel').addEventListener('click', closeModal);
  $('#mSave').addEventListener('click', async () => {
    const body = {
      id: bench ? bench.id : null, label: $('#b_label').value, model: $('#b_model').value,
      x: parseFloat($('#b_x').value), y: parseFloat($('#b_y').value), z: parseFloat($('#b_z').value), h: parseFloat($('#b_h').value) || 0,
      jobs, categories: [...cats], blip: $('#b_blip').checked,
    };
    const res = await post('adminSaveBench', body);
    if (res.ok) { A.data.benches = res.benches; closeModal(); renderTab(); toast('Bench saved', 'good'); } else toast(res.err || 'Failed', 'bad');
  });
}

/* ---------- players & xp ---------- */

async function renderPlayersTab() {
  $('#adminMain').innerHTML = `
    <div class="bar"><h1>Players &amp; XP</h1><button class="btn ghost sm" id="refresh"><i class="fa-solid fa-rotate"></i> Refresh</button></div>
    <div class="content"><div class="muted" style="padding:40px;text-align:center">Loading...</div></div>`;
  $('#refresh').addEventListener('click', renderPlayersTab);
  const res = await post('adminPlayers');
  if (res.ok) A.players = res.players;
  drawPlayers();
}

function drawPlayers() {
  const content = $('#adminMain .content');
  if (!content) return;
  content.innerHTML = `
    <table class="table">
      <thead><tr><th>ID</th><th>Player</th><th>Level</th><th>Total XP</th><th style="text-align:right">Change XP</th></tr></thead>
      <tbody>
        ${A.players.map(p => `<tr data-id="${p.id}">
          <td>${p.id}</td><td>${esc(p.name)}<div class="muted">${esc(p.citizenid)}</div></td><td>${p.level}</td><td>${p.xp}</td>
          <td><div class="xpctl">
            <input type="number" min="0" value="100" class="xp_amt">
            <button class="btn ghost sm" data-m="add">Add</button>
            <button class="btn ghost sm" data-m="remove">Remove</button>
            <button class="btn ghost sm" data-m="set">Set</button>
            <button class="btn danger sm" data-m="reset">Reset</button>
          </div></td></tr>`).join('') || '<tr><td colspan="5" class="muted" style="padding:40px;text-align:center">Nobody is online.</td></tr>'}
      </tbody>
    </table>`;
  content.querySelectorAll('[data-m]').forEach(b => b.addEventListener('click', async () => {
    const row = b.closest('tr');
    const res = await post('adminSetXp', { target: Number(row.dataset.id), mode: b.dataset.m, amount: Number(row.querySelector('.xp_amt').value) });
    if (res.ok) { A.players = res.players; drawPlayers(); toast('XP updated', 'good'); } else toast(res.err || 'Failed', 'bad');
  }));
}

/* ---------- modal helpers ---------- */

function openModal(html) { const m = $('#modal'); m.innerHTML = html; m.classList.remove('hidden'); }
function closeModal() { const m = $('#modal'); m.classList.add('hidden'); m.innerHTML = ''; }
function confirmBox(text, onYes) {
  openModal(`<div class="mbox" style="width:min(420px,94vw)"><h2>${esc(text)}</h2><div class="mactions"><button class="btn ghost sm" id="no">Cancel</button><button class="btn danger sm" id="yes">Delete</button></div></div>`);
  $('#no').addEventListener('click', closeModal);
  $('#yes').addEventListener('click', () => { closeModal(); onYes(); });
}

/* =====================================================================
   Messages from Lua + keyboard
   ===================================================================== */

window.addEventListener('message', e => {
  const { action, data, locale } = e.data || {};
  if (locale) LOC = locale;
  switch (action) {
    case 'openCrafting': openCrafting(data); break;
    case 'openAdmin': openAdmin(data); break;
    case 'craftResult': craftFinished(data); break;
    case 'craftCancelled': C.busy = false; renderCraft(); break;
    case 'close': hideAll(); break;
  }
});

window.addEventListener('keydown', e => {
  if (e.key !== 'Escape') return;
  if (!$('#modal').classList.contains('hidden')) return closeModal();
  if (!$('#craft').classList.contains('hidden')) return closeCraft();
  if (!$('#admin').classList.contains('hidden')) post('adminClose');
});
