Config = {}

-- Language of the player UI and notifications: 'en' or 'bg' (add more in locales.lua)
Config.Locale = 'en'

-- Chat command that opens the admin panel
Config.AdminCommand = 'admincrafting'

-- qb-core permission groups allowed to use the admin panel.
-- You can also grant access with: add_ace group.admin midnight_crafting.admin allow
Config.AdminPermissions = { 'admin', 'god' }

-- How close (in meters) the player must be to a bench to interact with it
Config.InteractDistance = 2.0

-- Max amount of items crafted in one go
Config.MaxQuantity = 10

-- Where item images are loaded from (qb-inventory default path)
Config.ImagePath = 'nui://qb-inventory/html/images/'

-- Animation played while crafting
Config.Animation = { dict = 'mini@repair', clip = 'fixing_a_ped', flag = 49 }

-- Bench props are spawned only when a player is closer than this (meters)
Config.SpawnDistance = 60.0

-- Map blip for benches that have "show blip" enabled
Config.Blip = { sprite = 566, color = 3, scale = 0.7 }

-- XP needed to go from level L to L+1 = floor(base * growth ^ (L - 1))
Config.Xp = { maxLevel = 50, base = 100, growth = 1.12 }

-- Recipe categories (icons are Font Awesome 6 classes)
Config.Categories = {
    { id = 'tools',     label = 'Tools',     icon = 'fa-screwdriver-wrench' },
    { id = 'medical',   label = 'Medical',   icon = 'fa-kit-medical' },
    { id = 'materials', label = 'Materials', icon = 'fa-cubes' },
    { id = 'weapons',   label = 'Weapons',   icon = 'fa-gun' },
    { id = 'misc',      label = 'Misc',      icon = 'fa-box-open' },
}

-- Props an admin can pick for a bench
Config.Props = {
    { model = 'prop_tool_bench02',      label = 'Tool bench' },
    { model = 'gr_prop_gr_bench_04b',   label = 'Gunrunning bench' },
    { model = 'prop_toolchest_01',      label = 'Tool chest' },
    { model = 'prop_toolchest_05',      label = 'Tool chest (large)' },
}

-- Recipes added on the very first start (when the recipe table is empty).
-- Entries with items that do not exist in your qb-core shared items are skipped.
Config.DefaultRecipes = {
    { label = 'Lockpick', category = 'tools', item = 'lockpick', amount = 1, time = 6, xp = 15, level = 1, chance = 100,
      ingredients = { { 'metalscrap', 3 }, { 'plastic', 2 } } },
    { label = 'Repair Kit', category = 'tools', item = 'repairkit', amount = 1, time = 10, xp = 30, level = 3, chance = 95,
      ingredients = { { 'metalscrap', 4 }, { 'rubber', 2 }, { 'plastic', 2 } } },
    { label = 'Advanced Lockpick', category = 'tools', item = 'advancedlockpick', amount = 1, time = 14, xp = 60, level = 6, chance = 85,
      ingredients = { { 'metalscrap', 6 }, { 'steel', 2 }, { 'plastic', 3 } } },
    { label = 'Bandage', category = 'medical', item = 'bandage', amount = 2, time = 5, xp = 10, level = 1, chance = 100,
      ingredients = { { 'plastic', 2 }, { 'rubber', 1 } } },
    { label = 'Steel', category = 'materials', item = 'steel', amount = 2, time = 8, xp = 20, level = 2, chance = 100,
      ingredients = { { 'iron', 3 }, { 'metalscrap', 2 } } },
}
