fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'midnight_crafting'
author 'Midnight Scripts'
description 'Crafting benches with XP levels and an in-game admin panel (qb-core, qb-inventory, qb-target)'
version '1.0.0'

ui_page 'web/index.html'

files {
    'web/index.html',
    'web/style.css',
    'web/app.js',
}

shared_scripts {
    'config.lua',
    'locales.lua',
}

client_scripts {
    'client/bridge.lua',
    'client/main.lua',
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server/bridge.lua',
    'server/main.lua',
    'server/admin.lua',
}

dependencies {
    'qb-core',
    'qb-target',
    'oxmysql',
}
