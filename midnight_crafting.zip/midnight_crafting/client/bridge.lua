-- Client side framework bridge (qb-core + qb-target).

QBCore = exports['qb-core']:GetCoreObject()

function AddBenchTarget(entity, benchId, label)
    exports['qb-target']:AddTargetEntity(entity, {
        options = {
            {
                icon = 'fas fa-hammer',
                label = label,
                action = function()
                    TriggerEvent('midnight_crafting:client:requestOpen', benchId)
                end,
            },
        },
        distance = Config.InteractDistance,
    })
end

function RemoveBenchTarget(entity)
    exports['qb-target']:RemoveTargetEntity(entity)
end

function Notify(msg, kind)
    QBCore.Functions.Notify(msg, kind or 'primary')
end
