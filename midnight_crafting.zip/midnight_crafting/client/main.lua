local Benches = {}      -- [id] = public bench data from the server
local Spawned = {}      -- [id] = prop entity
local Blips = {}        -- [id] = blip
local uiOpen = false
local crafting = false
local cancelRequested = false
local currentBench = nil

-------------------------------------------------------------------------------
-- Bench props, targets and blips
-------------------------------------------------------------------------------

local function Despawn(id)
    local entity = Spawned[id]
    if not entity then return end
    RemoveBenchTarget(entity)
    if DoesEntityExist(entity) then DeleteEntity(entity) end
    Spawned[id] = nil
end

local function Spawn(bench)
    local hash = joaat(bench.model)
    RequestModel(hash)
    local timeout = GetGameTimer() + 5000
    while not HasModelLoaded(hash) and GetGameTimer() < timeout do Wait(25) end
    if not HasModelLoaded(hash) then return end

    local entity = CreateObject(hash, bench.x, bench.y, bench.z, false, false, false)
    SetEntityHeading(entity, bench.h + 0.0)
    FreezeEntityPosition(entity, true)
    SetEntityAsMissionEntity(entity, true, true)
    SetModelAsNoLongerNeeded(hash)

    Spawned[bench.id] = entity
    AddBenchTarget(entity, bench.id, L('n_target'))
end

local function RebuildBlips()
    for id, blip in pairs(Blips) do
        if DoesBlipExist(blip) then RemoveBlip(blip) end
        Blips[id] = nil
    end
    for id, bench in pairs(Benches) do
        if bench.blip then
            local blip = AddBlipForCoord(bench.x, bench.y, bench.z)
            SetBlipSprite(blip, Config.Blip.sprite)
            SetBlipColour(blip, Config.Blip.color)
            SetBlipScale(blip, Config.Blip.scale)
            SetBlipAsShortRange(blip, true)
            BeginTextCommandSetBlipName('STRING')
            AddTextComponentSubstringPlayerName(bench.label)
            EndTextCommandSetBlipName(blip)
            Blips[id] = blip
        end
    end
end

RegisterNetEvent('midnight_crafting:client:sync', function(list)
    for id in pairs(Spawned) do Despawn(id) end -- the loop below respawns what is in range
    Benches = {}
    for _, bench in ipairs(list) do Benches[bench.id] = bench end
    RebuildBlips()
end)

CreateThread(function()
    while true do
        local coords = GetEntityCoords(PlayerPedId())
        for id, bench in pairs(Benches) do
            local dist = #(coords - vector3(bench.x, bench.y, bench.z))
            if dist < Config.SpawnDistance and not Spawned[id] then
                Spawn(bench)
            elseif dist > Config.SpawnDistance + 10.0 and Spawned[id] then
                Despawn(id)
            end
        end
        Wait(1500)
    end
end)

CreateThread(function()
    Wait(1000)
    TriggerServerEvent('midnight_crafting:server:requestSync')
end)

RegisterNetEvent('QBCore:Client:OnPlayerLoaded', function()
    TriggerServerEvent('midnight_crafting:server:requestSync')
end)

-------------------------------------------------------------------------------
-- Opening and closing the UI
-------------------------------------------------------------------------------

AddEventHandler('midnight_crafting:client:requestOpen', function(benchId)
    if uiOpen or crafting then return end
    TriggerServerEvent('midnight_crafting:server:open', benchId)
end)

RegisterNetEvent('midnight_crafting:client:open', function(payload)
    if uiOpen then return end
    uiOpen = true
    currentBench = payload.bench.id
    SetNuiFocus(true, true)
    SendNUIMessage({ action = 'openCrafting', data = payload, locale = GetLocaleTable() })
end)

local function StopAnimation()
    local ped = PlayerPedId()
    StopAnimTask(ped, Config.Animation.dict, Config.Animation.clip, 1.0)
    ClearPedTasks(ped)
end

local function CloseUi()
    if crafting then cancelRequested = true end
    uiOpen = false
    currentBench = nil
    SetNuiFocus(false, false)
    SendNUIMessage({ action = 'close' })
end

RegisterNUICallback('close', function(_, cb)
    CloseUi()
    cb('ok')
end)

-------------------------------------------------------------------------------
-- Crafting
-------------------------------------------------------------------------------

local function PlayAnimation()
    local anim = Config.Animation
    RequestAnimDict(anim.dict)
    local timeout = GetGameTimer() + 3000
    while not HasAnimDictLoaded(anim.dict) and GetGameTimer() < timeout do Wait(10) end
    TaskPlayAnim(PlayerPedId(), anim.dict, anim.clip, 3.0, 3.0, -1, anim.flag, 0, false, false, false)
end

local function RunCraft(duration, benchId)
    crafting = true
    cancelRequested = false
    PlayAnimation()

    CreateThread(function()
        local ped = PlayerPedId()
        local bench = Benches[benchId]
        local endAt = GetGameTimer() + duration
        local aborted = false

        while GetGameTimer() < endAt do
            Wait(100)
            if cancelRequested or IsEntityDead(ped) then aborted = true break end
            if bench and #(GetEntityCoords(ped) - vector3(bench.x, bench.y, bench.z)) > Config.InteractDistance + 3.0 then
                aborted = true
                break
            end
        end

        if aborted then
            StopAnimation()
            TriggerServerEvent('midnight_crafting:server:cancel')
            crafting = false
            cancelRequested = false
            Notify(L('n_cancelled'), 'error')
            SendNUIMessage({ action = 'craftCancelled' })
            return
        end

        QBCore.Functions.TriggerCallback('midnight_crafting:finish', function(res)
            StopAnimation()
            crafting = false
            SendNUIMessage({ action = 'craftResult', data = res or { ok = false, message = L('n_error') } })
        end)
    end)
end

RegisterNUICallback('craft', function(data, cb)
    if crafting or not currentBench then return cb({ ok = false }) end
    QBCore.Functions.TriggerCallback('midnight_crafting:start', function(res)
        if res and res.ok then
            RunCraft(res.duration, currentBench)
            cb({ ok = true, duration = res.duration })
        else
            cb({ ok = false, msg = res and res.msg or L('n_error') })
        end
    end, currentBench, data.recipeId, data.qty)
end)

RegisterNUICallback('cancel', function(_, cb)
    if crafting then cancelRequested = true end
    cb('ok')
end)

-------------------------------------------------------------------------------
-- Admin panel
-------------------------------------------------------------------------------

RegisterNetEvent('midnight_crafting:client:openAdmin', function(data)
    if uiOpen then return end

    local items = {}
    for name, item in pairs(QBCore.Shared.Items) do
        items[#items + 1] = {
            name = name,
            label = item.label or name,
            image = Config.ImagePath .. (item.image or (name .. '.png')),
        }
    end
    table.sort(items, function(a, b) return a.label:lower() < b.label:lower() end)

    local jobs = {}
    for name, job in pairs(QBCore.Shared.Jobs) do
        jobs[#jobs + 1] = { name = name, label = job.label or name }
    end
    table.sort(jobs, function(a, b) return a.label:lower() < b.label:lower() end)

    data.items = items
    data.jobs = jobs
    uiOpen = true
    SetNuiFocus(true, true)
    SendNUIMessage({ action = 'openAdmin', data = data })
end)

RegisterNUICallback('adminClose', function(_, cb)
    uiOpen = false
    SetNuiFocus(false, false)
    SendNUIMessage({ action = 'close' })
    cb('ok')
end)

local function Forward(nuiName, callbackName)
    RegisterNUICallback(nuiName, function(data, cb)
        QBCore.Functions.TriggerCallback(callbackName, function(res)
            cb(res or { ok = false, err = 'No response from the server.' })
        end, data)
    end)
end

Forward('adminSaveRecipe', 'midnight_crafting:admin:saveRecipe')
Forward('adminDeleteRecipe', 'midnight_crafting:admin:deleteRecipe')
Forward('adminSaveBench', 'midnight_crafting:admin:saveBench')
Forward('adminDeleteBench', 'midnight_crafting:admin:deleteBench')
Forward('adminSetXp', 'midnight_crafting:admin:setXp')

RegisterNUICallback('adminPlayers', function(_, cb)
    QBCore.Functions.TriggerCallback('midnight_crafting:admin:players', function(res)
        cb(res or { ok = false, err = 'No response from the server.' })
    end)
end)

-- Position one meter in front of the admin, on the ground
RegisterNUICallback('adminGetCoords', function(_, cb)
    local ped = PlayerPedId()
    local pos = GetOffsetFromEntityInWorldCoords(ped, 0.0, 1.0, 0.0)
    local found, groundZ = GetGroundZFor_3dCoord(pos.x, pos.y, pos.z, false)
    local function round(n) return math.floor(n * 100 + 0.5) / 100 end
    cb({
        x = round(pos.x), y = round(pos.y), z = round(found and groundZ or pos.z - 0.95),
        h = round(GetEntityHeading(ped)),
    })
end)

RegisterNUICallback('adminGoto', function(data, cb)
    local ped = PlayerPedId()
    SetEntityCoords(ped, (data.x or 0) + 0.0, (data.y or 0) + 0.0, (data.z or 0) + 1.0, false, false, false, false)
    cb('ok')
end)

-------------------------------------------------------------------------------
-- Cleanup
-------------------------------------------------------------------------------

AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    for id in pairs(Spawned) do Despawn(id) end
    for _, blip in pairs(Blips) do
        if DoesBlipExist(blip) then RemoveBlip(blip) end
    end
    if uiOpen then SetNuiFocus(false, false) end
    if crafting then StopAnimation() end
end)
