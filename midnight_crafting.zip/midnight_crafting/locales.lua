Locales = {}

Locales.en = {
    -- Player UI
    ui_search = 'Search recipes',
    ui_all = 'All',
    ui_level = 'Level',
    ui_max = 'Max level',
    ui_lv = 'Level {0}',
    ui_craft = 'Craft',
    ui_cancel = 'Cancel',
    ui_crafting = 'Crafting...',
    ui_chance = 'Success',
    ui_time = 'Time',
    ui_reward = 'XP',
    ui_ingredients = 'Ingredients',
    ui_quantity = 'Quantity',
    ui_max_qty = 'Max',
    ui_you_get = 'You get {0}x {1}',
    ui_empty = 'No recipes at this bench yet.',
    ui_no_match = 'No recipe matches your search.',
    ui_pick = 'Pick a recipe on the left to see what it needs.',
    ui_missing = 'Missing materials',
    ui_locked = 'Reach level {0} to unlock',
    ui_close = 'Close',

    -- Notifications
    n_target = 'Use crafting bench',
    n_no_access = 'You do not have access to this bench.',
    n_too_far = 'You are too far from the bench.',
    n_busy = 'You are already crafting.',
    n_no_recipe = 'That recipe is not available at this bench.',
    n_level = 'You need crafting level %s for this recipe.',
    n_missing = 'You are missing materials.',
    n_full = 'Your inventory is full.',
    n_success = 'Crafted %sx %s.',
    n_failed = 'The craft failed and the materials were lost.',
    n_partial = 'Crafted %sx %s, %s failed.',
    n_levelup = 'Crafting level up! You are now level %s.',
    n_cancelled = 'Crafting cancelled.',
    n_error = 'Something went wrong. Try again.',
}

Locales.bg = {
    ui_search = 'Търси рецепта',
    ui_all = 'Всички',
    ui_level = 'Ниво',
    ui_max = 'Максимално ниво',
    ui_lv = 'Ниво {0}',
    ui_craft = 'Направи',
    ui_cancel = 'Отказ',
    ui_crafting = 'Изработване...',
    ui_chance = 'Успех',
    ui_time = 'Време',
    ui_reward = 'XP',
    ui_ingredients = 'Съставки',
    ui_quantity = 'Количество',
    ui_max_qty = 'Макс',
    ui_you_get = 'Получаваш {0}x {1}',
    ui_empty = 'Все още няма рецепти на тази маса.',
    ui_no_match = 'Няма рецепта, която отговаря на търсенето.',
    ui_pick = 'Избери рецепта отляво, за да видиш какво изисква.',
    ui_missing = 'Липсват материали',
    ui_locked = 'Достигни ниво {0}, за да отключиш',
    ui_close = 'Затвори',

    n_target = 'Използвай работна маса',
    n_no_access = 'Нямаш достъп до тази маса.',
    n_too_far = 'Твърде далече си от масата.',
    n_busy = 'Вече изработваш нещо.',
    n_no_recipe = 'Тази рецепта не е налична на тази маса.',
    n_level = 'Трябва ти ниво %s на изработване за тази рецепта.',
    n_missing = 'Липсват ти материали.',
    n_full = 'Инвентарът ти е пълен.',
    n_success = 'Изработи %sx %s.',
    n_failed = 'Изработването се провали и материалите са загубени.',
    n_partial = 'Изработи %sx %s, %s се провалиха.',
    n_levelup = 'Ново ниво на изработване! Вече си ниво %s.',
    n_cancelled = 'Изработването е отказано.',
    n_error = 'Нещо се обърка. Опитай пак.',
}

function L(key, ...)
    local set = Locales[Config.Locale] or Locales.en
    local text = set[key] or Locales.en[key] or key
    if select('#', ...) > 0 then
        return text:format(...)
    end
    return text
end

-- Full table (chosen language over English fallback) sent to the NUI
function GetLocaleTable()
    local merged = {}
    for k, v in pairs(Locales.en) do merged[k] = v end
    for k, v in pairs(Locales[Config.Locale] or {}) do merged[k] = v end
    return merged
end
